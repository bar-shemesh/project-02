export default interface Coin {
    id: string;  // bitcoin
    symbol: string; // btc
    name: string; // Bitcoin
}